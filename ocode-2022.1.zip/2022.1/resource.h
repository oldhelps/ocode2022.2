//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� resource.rc ʹ��
//
#define IDC_MAIN_TEXT                   1001
#define CM_ABOUT                        9069
#define CM_FILE_OPEN                    9070
#define CM_FILE_EXIT                    9071
#define CM_FILE_SAVEAS                  9072
#define ID_40001                        40001
#define ID_40002                        40002
#define ID_40003                        40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
